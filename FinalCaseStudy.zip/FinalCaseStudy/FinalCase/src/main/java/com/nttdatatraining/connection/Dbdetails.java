package com.nttdatatraining.connection;

public interface Dbdetails {
	
	String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	String USER_NAME = "root";
	String PASSWORD = "root";
	String CONSTR = "jdbc:mysql://localhost:3306/pharamcy?useSSL=false";

}
